function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5zoE0nGlh3J":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

