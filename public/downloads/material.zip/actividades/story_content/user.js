function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5ZiC0L486HV":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

